﻿using NLog;
using Grpc.Net.Client;

// This comes from GRPC generated code
using Services;

namespace Clients
{
    /// <summary>
    /// Client example.
    /// </summary>
    class AdderClient
    {
        /// <summary>
        /// Logger for this class.
        /// </summary>
        Logger mLog = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// Configures logging subsystem.
        /// </summary>
        private void ConfigureLogging()
        {
            var config = new NLog.Config.LoggingConfiguration();

            var console = new NLog.Targets.ConsoleTarget("console")
            {
                Layout = @"${date:format=HH\:mm\:ss}|${level}| ${message} ${exception}"
            };
            config.AddTarget(console);
            config.AddRuleForAllLevels(console);

            LogManager.Configuration = config;
        }

        /// <summary>
        /// Program body.
        /// </summary>
        private void Run()
        {
            // Configure logging
            ConfigureLogging();

            // Initialize random number generator
            var rnd = new Random();

            // Run everything in a loop to recover from connection errors
            while (true)
            {
                try
                {
                    //connect to the server, get service proxy
                    var channel = GrpcChannel.ForAddress("http://127.0.0.1:5000");
                    var watercontainer = new Container.ContainerClient(channel);
                    //initialize Adder descriptor
                    var adder = new AddDesc();
                    while (true)
                    {
                        var currentlevel = watercontainer.currentlimit(new Empty()).Value;//getting current water level
                        var upperlimit = watercontainer.upperlimit(new Empty()).Value; // Getting upper limit of the water container
                        var lowerlimit = watercontainer.lowerlimit(new Empty()).Value; // Getting lower limit of the water container

                        //if current level is lower than the lower limit
                        if (currentlevel < lowerlimit)
                        {
                            if ((lowerlimit - currentlevel) > 0)//if true and also checks the current limit is higher than the lower limit
                            {
                                adder.AdderNumber = rnd.Next(1, lowerlimit - currentlevel);//Ensures that  adder will add an amount of
                                                                                           //water that keeps the total below or equal to the lower limit.
                                watercontainer.addwater(adder);

                                mLog.Info($" {adder.AdderNumber} units of water added to the container, Current water level: {currentlevel + adder.AdderNumber}. Lower limit: {lowerlimit}, Upper limit: {upperlimit}");

                                Thread.Sleep(100); 
                            }
                        }
                        //sleep thread for random amount of time to prevent spamming
                        Thread.Sleep(1000 + rnd.Next(1500));
                    }
                }
                catch (Exception e)
                {
                    // Log whatever exception to console
                    mLog.Warn(e, "Unhandled exception caught. Will restart main loop.");

                    // Prevent console spamming
                    Thread.Sleep(2000);
                }
            }
        }

        /// <summary>
        /// Program entry point.
        /// </summary>
        /// <param name="args">Command line arguments.</param>
        static void Main(string[] args)
        {
            var self = new AdderClient();
            self.Run();
        }
    }
}

