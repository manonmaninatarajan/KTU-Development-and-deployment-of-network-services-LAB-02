﻿using NLog;
using Grpc.Net.Client;

// This comes from GRPC generated code
using Services;

namespace Clients
{
    /// <summary>
    /// Client example.
    /// </summary>
    class RemoverClient
    {
        /// <summary>
        /// Logger for this class.
        /// </summary>
        Logger mLog = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// Configures logging subsystem.
        /// </summary>
        private void ConfigureLogging()
        {
            var config = new NLog.Config.LoggingConfiguration();

            var console = new NLog.Targets.ConsoleTarget("console")
            {
                Layout = @"${date:format=HH\:mm\:ss}|${level}| ${message} ${exception}"
            };
            config.AddTarget(console);
            config.AddRuleForAllLevels(console);

            LogManager.Configuration = config;
        }

        /// <summary>
        /// Program body.
        /// </summary>
        private void Run()
        {
            // Configure logging
            ConfigureLogging();

            // Initialize random number generator
            var rnd = new Random();

            // Run everything in a loop to recover from connection errors
            while (true)
            {
                try
                {
                    // Initialize remover descriptor
                    var channel = GrpcChannel.ForAddress("http://127.0.0.1:5000");
                    var watercontainer = new Container.ContainerClient(channel);
                    var remover = new RemoveDesc();//initialize Adder descriptor
                    while (true)
                    {
                        var currentlevel = watercontainer.currentlimit(new Empty()).Value;//getting current water level
                        var lowerlimit = watercontainer.lowerlimit(new Empty()).Value;//getting lower limit of the water level
                        var upperlimit = watercontainer.upperlimit(new Empty()).Value;//getting upper limit of the water level

                        // Remove water if the current level exceeds the upper limit
                        if (currentlevel > upperlimit)
                        {
                            if ((currentlevel - upperlimit) > 0)///if true and also checks the current limit is lower than the upper limit
                            {
                                remover.RemoverNumber = rnd.Next(1, currentlevel - upperlimit);//also ensures the remove element wont removes water below lower limit
                                watercontainer.removewater(remover);

                                mLog.Info($" {remover.RemoverNumber} units of water removed from the container, Current water level: {currentlevel - remover.RemoverNumber}. Lower limit: {lowerlimit}, Upper limit: {upperlimit}");

                                Thread.Sleep(100); 
                            }
                        }
                        //sleep thread for random amount of time to prevent spamming
                        Thread.Sleep(1000 + rnd.Next(1500));
                    }
                }
                catch (Exception e)
                {
                    // Log whatever exception to console
                    mLog.Warn(e, "Unhandled exception caught. Will restart main loop.");

                    // Prevent console spamming
                    Thread.Sleep(2000);
                }
            }
        }

        /// <summary>
        /// Program entry point.
        /// </summary>
        /// <param name="args">Command line arguments.</param>
        static void Main(string[] args)
        {
            var self = new RemoverClient();
            self.Run();
        }
    }
}
