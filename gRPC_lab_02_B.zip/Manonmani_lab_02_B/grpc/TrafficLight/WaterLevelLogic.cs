namespace Servers;


using NLog;


/// <summary>
/// Adder Client descriptor.
/// </summary>
public class AddDesc
{   

    /// <summary>
    /// Add_number number.
    /// </summary>
    public int AdderNumber { get; set; }

}
/// <summary>
/// Remover Client descriptor.
/// </summary>
public class RemoveDesc
{  

    /// <summary>
    /// remove_number number.
    /// </summary>
    public int RemoverNumber { get; set; }

}

/// <summary>
/// Descriptor of watre level checker
/// </summary>
public class waterLevelchecker
{
    /// <summary>
    /// Indicates if the water level added or removed.
    /// </summary>
    public bool IsSuccess { get; set; }
    /// <summary>
    /// If not,indicates the reason
    /// </summary>
    public string failurereason { get; set; }


}

/// <summary>
/// Enum for water level state (lower and upper).
/// </summary>
public enum leverstate : int
{
    upperlimit,
    lowerlimit
}

public class Waterlevelstate
{

    /// <summary>
    /// Access lock.
    /// </summary>
    public readonly object AccessLock = new object();

   
    /// <summary>
    /// Water level state
    /// </summary>
    public leverstate leverstate;
    /// <summary>
    /// upper limit
    /// </summary>
    public int upperlimit;
    /// <summary>
    /// lower limit
    /// </summary>
    public int lowerlimit;
    /// <summary>
    /// current level of water
    /// </summary>
    public int currentlever;

}


/// <summary>
/// <para>Water level logic.</para>
/// <para>Thread safe.</para>
/// </summary>
public class WaterLevelLogic
{
    /// <summary>
    /// Logger for this class.
    /// </summary>
    private Logger mLog = LogManager.GetCurrentClassLogger();

    /// <summary>
    /// Background task thread.
    /// </summary>
    private Thread mBgTaskThread;

    /// <summary>
    /// State descriptor.
    /// </summary>
    private Waterlevelstate mState = new Waterlevelstate();


    /// <summary>
    /// Constructor.
    /// </summary>
    public WaterLevelLogic()
    {
        //initial value of the waterlever
        mState.upperlimit = 75;//Initial upper limit
        mState.lowerlimit = 25;//Initial lower limit
        mState.currentlever = 45;//Initial water level limit
                                 //start the background task for changing upper and lower limit
        mBgTaskThread = new Thread(BackgroundTask);//creating Background thread
        mBgTaskThread.Start();
    }



    /// <summary>
    /// Get the current water level state of the upper and lower limit in the container.
    /// </summary>
    /// <returns>Current water level.</returns>
    public leverstate GetWaterleverstate()
    {
        lock (mState.AccessLock)
        {
            return mState.leverstate;
        }
    }
 

    /// <summary>
    /// Get the current upper limit of the water container.
    /// </summary>
    /// <returns>upper limit of the water level.</returns>
    public int upperlimit()
    {
        lock (mState.AccessLock)
        {
            return mState.upperlimit;
        }
    }
    Random rnd = new Random();
    /// <summary>
    /// Get the current Lower limit of the water container.
    /// </summary>
    /// <returns>Lower limit of the water level.</returns>
    public int lowerlimit()
    {
        lock (mState.AccessLock)
        {
            return mState.lowerlimit;
        }
    }
    /// <summary>
    /// Get the current limit of the water container.
    /// </summary>
    /// <returns>limit of the water level.</returns>
    public int currentlimit()
    {
        lock (mState.AccessLock)
        {
            return mState.currentlever;
        }

    }
    /// <summary>
    /// Add water to the container.
    /// </summary>
    /// <param name="addDesc">The description of the water to be added.</param>
    /// <returns>The result of the add operation.</returns>
    public waterLevelchecker addwater(AddDesc addDesc)
    {
        var par = new waterLevelchecker();
        lock (mState.AccessLock)
        {
            if (addDesc.AdderNumber < mState.upperlimit) // Add water if current level + new water doesn't exceed upper limit
            {
                mState.currentlever += addDesc.AdderNumber;
                par.IsSuccess = true;
                if (addDesc.AdderNumber != 0)
                {
                    mLog.Info($"{addDesc.AdderNumber} units of water are added. Current level of water: {mState.currentlever} units, Upper limit: {mState.upperlimit}, Lower limit: {mState.lowerlimit}");
                }
            }
            else
            {
                mLog.Info($"Adder is denied to add water");
                par.IsSuccess = false;
                par.failurereason = "Current level of water is below or equal to the lower limit";
            }
            return par;
        }
    }

    /// <summary>
    /// Remove water from the container.
    /// </summary>
    /// <param name="removedesc">The description of the water to be removed.</param>
    /// <returns>The result of the remove operation.</returns>
    public waterLevelchecker removewater(RemoveDesc removedesc)
    {
        var par = new waterLevelchecker();
        lock (mState.AccessLock)
        {
            if (mState.currentlever > mState.lowerlimit)
            {
                mState.currentlever -= removedesc.RemoverNumber;
                par.IsSuccess = true;
                if (removedesc.RemoverNumber != 0)
                {
                    mLog.Info($"{removedesc.RemoverNumber} units of water removed. Current level: {mState.currentlever}, Upper limit: {mState.upperlimit}, Lower limit: {mState.lowerlimit}");
                }
            }
            else
            {
                mLog.Info("Cannot remove water. Falls below lower limit.");
                par.IsSuccess = false;
                par.failurereason = "Cannot remove water. Falls below lower limit.";
            }
            return par;
        }
    }





    /// <summary>
    /// Background task for the water container.
    /// </summary>
    public void BackgroundTask()
    {
        //intialize random number generator
        var rnd = new Random();
        while (true)
        {
            //sleep for 8 second while
            Thread.Sleep(8000);
            lock (mState.AccessLock)
            {
                int lowlimit = rnd.Next(1, 100);//criteria for generating random number for lower limit
                int uplimit = rnd.Next(lowlimit + 1, lowlimit + 100);//criteria for generating random number for upper
                                                                     //limit ensuring upper limit is always greater than the lower limit
                int curlimit = mState.currentlever;

                mState.lowerlimit = lowlimit;
                mState.upperlimit = uplimit;


                mLog.Info($"Updated limits for every 8 seconds: Lower = {mState.lowerlimit}, Upper = {mState.upperlimit}, current level : {curlimit}");
            }
        }
    }
}