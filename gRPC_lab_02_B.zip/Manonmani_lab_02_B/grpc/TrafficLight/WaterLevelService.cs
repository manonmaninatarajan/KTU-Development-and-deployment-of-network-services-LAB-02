﻿namespace Servers;

using Grpc.Core;
using Services;
/// <summary>
/// Service
/// </summary>
public class ContainerService : Services.Container.ContainerBase
{
    //NOTE: instance-per-request service would need logic to be static or injected from a singleton instance
    private readonly WaterLevelLogic mLogic = new WaterLevelLogic();

    /// <summary>
    /// Gets the current water level state.
    /// </summary>
    /// <param name="input">Not used.</param>
    /// <param name="context">call context.</param>
    /// <returns>the current water level state.</returns>
    public override Task<GetWaterleverstateOutput> GetWaterleverstate(Empty input, ServerCallContext context)
    {
        var logicwaterLevelState = mLogic.GetWaterleverstate();
        var serviceLightState = (Services.leverstate)logicwaterLevelState;//this will only work properly if enumerations are by-value compatible

        var result = new GetWaterleverstateOutput { Value = serviceLightState };
        return Task.FromResult(result);
    }
    /// <summary>
    /// Gets the current upper limit of the water level.
    /// </summary>
    /// <param name="input">Not used..</param>
    /// <param name="context">call context.</param>
    /// <returns>the upper limit of the water level.</returns>

    public override Task<intMsg> upperlimit(Empty input, ServerCallContext context)
    {
        var result = new intMsg { Value = mLogic.upperlimit() };
        return Task.FromResult(result);
    }
    /// <summary>
    /// Gets the current lower limit of the water level.
    /// </summary>
    /// <param name="input">Not used.</param>
    /// <param name="context">call context.</param>
    /// <returns>the lower limit of the water level.</returns>
    public override Task<intMsg> lowerlimit(Empty input, ServerCallContext context)
    {
        var result = new intMsg { Value = mLogic.lowerlimit() };
        return Task.FromResult(result);
    }
    /// <summary>
    /// Gets the current water level.
    /// </summary>
    /// <param name="input">Not used..</param>
    /// <param name="context">call context.</param>
    /// <returns>the current water level.</returns>
    public override Task<intMsg> currentlimit(Empty input, ServerCallContext context)
    {
        var result = new intMsg { Value = mLogic.currentlimit() };
        return Task.FromResult(result);
    }
    /// <summary>
    /// Adds water to the container.
    /// </summary>
    /// <param name="input">Contains the number of units to add.</param>
    /// <param name="context">call context.</param>
    /// <returns>result of the add operation.</returns>
    public override Task<Services.waterLevelchecker> addwater(Services.AddDesc input, ServerCallContext context)
    {
        var adder = new AddDesc
        {
            AdderNumber = input.AdderNumber
        };
        var logisresult = mLogic.addwater(adder);
        var result = new Services.waterLevelchecker { IsSuccess = logisresult.IsSuccess, Failurereason = logisresult.failurereason ?? "" };
        return Task.FromResult(result);
    }
    /// <summary>
    /// Removes water from the container.
    /// </summary>
    /// <param name="input">Contains the number of units to remove.</param>
    /// <param name="context">call context.</param>
    /// <returns>result of the remove operation.</returns>
    public override Task<Services.waterLevelchecker> removewater(Services.RemoveDesc input, ServerCallContext context)
    {
        var remover = new RemoveDesc
        {
           RemoverNumber=input.RemoverNumber
        };
        var logisresult = mLogic.removewater(remover);
        var result = new Services.waterLevelchecker { IsSuccess = logisresult.IsSuccess, Failurereason = logisresult.failurereason ?? "" };
        return Task.FromResult(result);
    }
}
