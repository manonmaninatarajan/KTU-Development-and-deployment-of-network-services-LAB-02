﻿namespace Clients;

using System.Net.Http;

using NLog;
using Services;

/// <summary>
/// Client example.
/// </summary>
class Adderclient
{
    /// <summary>
    /// Logger for this class.
    /// </summary>
    Logger mLog = LogManager.GetCurrentClassLogger();

    /// <summary>
    /// Configures logging subsystem.
    /// </summary>
    private void ConfigureLogging()
    {
        var config = new NLog.Config.LoggingConfiguration();

        var console =
            new NLog.Targets.ConsoleTarget("console")
            {
                Layout = @"${date:format=HH\:mm\:ss}|${level}| ${message} ${exception}"
            };
        config.AddTarget(console);
        config.AddRuleForAllLevels(console);

        LogManager.Configuration = config;
    }

    /// <summary>
    /// Program body.
    /// </summary>
    private void Run()
    {
        //configure logging
        ConfigureLogging();

        //initialize random number generator
        var rnd = new Random();

        //run everything in a loop to recover from connection errors
        while (true)
        {
            try
            {
                var adder = new AddDesc();
                //connect to the server, get service client proxy
                var watercontainer = new addwaterlevelclient("http://127.0.0.1:5000", new HttpClient());
                while (true)
                {
                    // Get the current water level.
                    var currentlevel = watercontainer.Getcurrentlevel();

                    // Get the lower limit of the water container.
                    var lowerlimit = watercontainer.Getlowerlimit();

                    // Get the upper limit of the water container.
                    var upperlimit = watercontainer.Getupperlimit();

                    // Add water if the current level is below the lower limit.
                    if (currentlevel < lowerlimit)
                    {
                        if ((lowerlimit - currentlevel) > 0)//if true and also checks the current limit is higher than the lower limit
                        {
                            // Add a random amount of water without exceeding the lower limit.
                            adder.AdderNumber = rnd.Next(1, (lowerlimit - currentlevel));//Ensures that adder will add an amount of
                                                                                     //water that keeps the total below or equal to the lower limit.
                            watercontainer.Addwater(adder);

                            mLog.Info($" {adder.AdderNumber} units of water added to the container, Current water level: {currentlevel + adder.AdderNumber}. Lower limit: {lowerlimit}, Upper limit: {upperlimit}");
                        }
                    }

                    //sleep for a random period
                    Thread.Sleep(500 + rnd.Next(1500));
                }
            }
            catch (Exception e)
            {
                mLog.Warn(e, "Unhandled exception caught. Will restart main loop.");
                Thread.Sleep(2000); // Prevent console spamming, delay before restarting the loop
            }
        }
    }

    /// <summary>
    /// Program entry point.
    /// </summary>
    /// <param name="args">Command line arguments.</param>
    static void Main(string[] args)
    {
        var self = new Adderclient();
        self.Run();
    }
}