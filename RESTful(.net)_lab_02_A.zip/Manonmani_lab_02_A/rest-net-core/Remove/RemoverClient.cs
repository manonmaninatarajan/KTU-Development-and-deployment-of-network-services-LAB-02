﻿namespace Clients;

using System.Net.Http;

using NLog;
using Services;

/// <summary>
/// Client example.
/// </summary>
class RemoverClient
{
    /// <summary>
    /// Logger for this class.
    /// </summary>
    Logger mLog = LogManager.GetCurrentClassLogger();

    /// <summary>
    /// Configures logging subsystem.
    /// </summary>
    private void ConfigureLogging()
    {
        var config = new NLog.Config.LoggingConfiguration();

        var console =
            new NLog.Targets.ConsoleTarget("console")
            {
                Layout = @"${date:format=HH\:mm\:ss}|${level}| ${message} ${exception}"
            };
        config.AddTarget(console);
        config.AddRuleForAllLevels(console);

        LogManager.Configuration = config;
    }

    /// <summary>
    /// Program body.
    /// </summary>
    private void Run()
    {
        // Configure logging
        ConfigureLogging();

        // Initialize random number generator
        var rnd = new Random();

        // Run everything in a loop to recover from connection errors
        while (true)
        {
            try
            {
                // Initialize remover descriptor
                var remover = new RemoveDesc();
                //connect to the server, get service client proxy
                var watercontainer = new removewaterlevelclient("http://127.0.0.1:5000", new HttpClient());

                while (true)
                {
                    // Get the current water level
                    var currentlevel = watercontainer.Getcurrentlevel();

                    // Get the lower limit of the water container
                    var lowerlimit = watercontainer.Getupperlimit();

                    // Get the upper limit of the water container
                    var upperlimit = watercontainer.Getlowerlimit();

                    // Remove water if the current level exceeds the upper limit
                    if (currentlevel > upperlimit)
                    {
                        if ((currentlevel - upperlimit) > 0)//if true and also checks the current limit is lower than the upper limit
                        {
                            // Remove a random amount of water, ensuring it won't drop below the lower limit
                            remover.RemoverNumber = rnd.Next(1, (currentlevel - upperlimit));//also ensures the remove element wont removes water below lower limit
                            watercontainer.Removewater(remover);

                            mLog.Info($" {remover.RemoverNumber} units of water removed from the container, Current water level: {currentlevel - remover.RemoverNumber}. Lower limit: {lowerlimit}, Upper limit: {upperlimit}");
                        }
                    }
                    //sleep thread for random amount of time to prevent spamming
                    Thread.Sleep(500 + rnd.Next(1500));
                }
            }
            catch (Exception e)
            {
                // Log any unhandled exceptions
                mLog.Warn(e, "Unhandled exception caught. Will restart main loop.");

                // Sleep to prevent console spamming
                Thread.Sleep(2000);
            }
        }
    }

    /// <summary>
    /// Program entry point.
    /// </summary>
    /// <param name="args">Command line arguments.</param>
    static void Main(string[] args)
    {
        var self = new RemoverClient();
        self.Run();
    }
}