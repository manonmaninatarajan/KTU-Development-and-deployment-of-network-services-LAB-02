using Microsoft.AspNetCore.Mvc;
using Servers;
/// <summary>
/// Service. Class must be marked public, otherwise ASP.NET core runtime will not find it.
/// 
/// Look into FromXXX attributes if you need to map inputs to custom parts of HTTP request.
/// </summary>
[ApiController]
[Route("api/waterlevelcontainer")]
public class WaterLevelController : ControllerBase
{
    /// <summary>
	/// Service logic. This is created in Server.StartServer() and received through DI in constructor.
	/// </summary>
    private readonly WaterLevelLogic mlogic;

    /// <summary>
    /// Constructor
    /// </summary>
    /// <param name="logic">Logic to use. This will get passed through DI.</param>
    public WaterLevelController(WaterLevelLogic waterLevelLogic)
    {
        mlogic = waterLevelLogic;
    }

    /// <summary>
    /// Get the current water level in the container.
    /// </summary>
    /// <returns>The current water level</returns>
    [HttpGet("Getcurrentlevel")]
    public ActionResult<int> currentlimit()
    {
        return mlogic.currentlimit();
    }

    /// <summary>
    /// Get the upper water level limit.
    /// </summary>
    /// <returns>The upper limit of the watercontainer.</returns>
    [HttpGet("Getupperlimit")]
    public ActionResult<int> upperlimit()
    {
        return mlogic.upperlimit();
    }

    /// <summary>
    /// Get the lower water level limit.
    /// </summary>
    /// <returns>The lower limit of the waterconatiner.</returns>
    [HttpGet("Getlowerlimit")]
    public ActionResult<int> lowerlimit()
    {
        return mlogic.lowerlimit();
    }

    /// <summary>
    /// Add water to the container.
    /// </summary>
    /// <param name="addDesc">Description containing the amount of water to add.</param>
    /// <returns>the added units of water in the water container.</returns>
    [HttpPost("addwater")]
    public ActionResult<waterLevelchecker> AddWater(AddDesc addDesc)
    {
        return mlogic.addwater(addDesc);
    }

    /// <summary>
    /// Remove water from the container.
    /// </summary>
    /// <param name="removeDesc">Description containing the amount of water to remove.</param>
    /// <returns>the removed units of water in the water container.</returns>
    [HttpPost("removewater")]
    public ActionResult<waterLevelchecker> RemoveWater(RemoveDesc removeDesc)
    {
        return mlogic.removewater(removeDesc);
    }
}
