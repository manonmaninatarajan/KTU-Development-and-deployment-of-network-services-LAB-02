namespace Servers
{
    using NLog;

    /// <summary>
    /// Adder Client descriptor.
    /// </summary>
    public class AddDesc
    {
        /// <summary>
        /// The amount of water to add.
        /// </summary>
        public int AdderNumber { get; set; }
    }

    /// <summary>
    /// Remover Client descriptor.
    /// </summary>
    public class RemoveDesc
    {
        /// <summary>
        /// The amount of water to remove.
        /// </summary>
        public int RemoverNumber { get; set; }
    }

    /// <summary>
    /// Descriptor for water level check result.
    /// </summary>
    public class waterLevelchecker
    {
        /// <summary>
        /// Indicates if the water level was successfully added or removed.
        /// </summary>
        public bool IsSuccess { get; set; }

        /// <summary>
        /// Reason for failure, if any.
        /// </summary>
        public string failurereason { get; set; }
    }

    /// <summary>
    /// Enum for water level state (upper and lower).
    /// </summary>
    public enum leverstate : int
    {
        upperlimit,
        lowerlimit
    }

    public class Waterlevelstate
    {
        /// <summary>
        /// Access lock for thread safety.
        /// </summary>
        public readonly object AccessLock = new object();

        /// <summary>
        /// Current water level state.
        /// </summary>
        public leverstate leverstate;

        /// <summary>
        /// Upper limit of the water container.
        /// </summary>
        public int upperlimit;

        /// <summary>
        /// Lower limit of the water container.
        /// </summary>
        public int lowerlimit;

        /// <summary>
        /// Current water level.
        /// </summary>
        public int currentlever;
    }

    /// <summary>
    /// <para>Water level logic.</para>
    /// </summary>
    public class WaterLevelLogic
    {
        /// <summary>
        /// Logger for the water level logic.
        /// </summary>
        private Logger mLog = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// Background task thread.
        /// </summary>
        private Thread mBgTaskThread;

        /// <summary>
        /// State descriptor for the water level.
        /// </summary>
        private Waterlevelstate mState = new Waterlevelstate();

        /// <summary>
        /// Constructor initializing default water level limits and starting background task.
        /// </summary>
        public WaterLevelLogic()
        {
            mState.upperlimit = 75;
            mState.lowerlimit = 25;
            mState.currentlever = 45;
            mBgTaskThread = new Thread(BackgroundTask);
            mBgTaskThread.Start();
        }

        /// <summary>
        /// Get the current water level state.
        /// </summary>
        /// <returns>The current water level state.</returns>
        public Waterlevelstate GetWaterleverstate()
        {
            lock (mState.AccessLock)
            {
                return mState;
            }
        }

        /// <summary>
        /// Get the upper limit of the water container.
        /// </summary>
        /// <returns>The upper limit of the water level.</returns>
        public int upperlimit()
        {
            lock (mState.AccessLock)
            {
                return mState.upperlimit;
            }
        }

        /// <summary>
        /// Get the lower limit of the water container.
        /// </summary>
        /// <returns>The lower limit of the water level.</returns>
        public int lowerlimit()
        {
            lock (mState.AccessLock)
            {
                return mState.lowerlimit;
            }
        }

        /// <summary>
        /// Get the current water level in the container.
        /// </summary>
        /// <returns>The current water level.</returns>
        public int currentlimit()
        {
            lock (mState.AccessLock)
            {
                return mState.currentlever;
            }
        }

        /// <summary>
        /// Add water to the container.
        /// </summary>
        /// <param name="addDesc">The description of the water to be added.</param>
        /// <returns>The result of the add operation.</returns>
        public waterLevelchecker addwater(AddDesc addDesc)
        {
            var par = new waterLevelchecker();
            lock (mState.AccessLock)
            {
                if (mState.currentlever < mState.upperlimit)
                {
                    mState.currentlever += addDesc.AdderNumber;
                    par.IsSuccess = true;
                    if (addDesc.AdderNumber != 0)
                    {
                        mLog.Info($"{addDesc.AdderNumber} units of water added. Current level: {mState.currentlever}, Upper limit: {mState.upperlimit}, Lower limit: {mState.lowerlimit}");
                    }
                }
                else
                {
                    mLog.Info("water container is denied to Add water");
                    par.IsSuccess = false;
                    par.failurereason = "Current level of water is below or equal to the lower limit.";
                }
                return par;
            }
        }

        /// <summary>
        /// Remove water from the container.
        /// </summary>
        /// <param name="removedesc">The description of the water to be removed.</param>
        /// <returns>The result of the remove operation.</returns>
        public waterLevelchecker removewater(RemoveDesc removedesc)
        {
            var par = new waterLevelchecker();
            lock (mState.AccessLock)
            {
                if (mState.currentlever > mState.lowerlimit)
                {
                    mState.currentlever -= removedesc.RemoverNumber;
                    par.IsSuccess = true;
                    if (removedesc.RemoverNumber != 0)
                    {
                        mLog.Info($"{removedesc.RemoverNumber} units of water removed. Current level: {mState.currentlever}, Upper limit: {mState.upperlimit}, Lower limit: {mState.lowerlimit}");
                    }
                }
                else
                {
                    mLog.Info("water container is denied to Remove water");
                    par.IsSuccess = false;
                    par.failurereason = "Current level of water is above the upper limit";
                }
                return par;
            }
        }

        /// <summary>
        /// Background task that updates the upper and lower limits every 8 seconds.
        /// </summary>
        public void BackgroundTask()
        {
            var rnd = new Random();
            while (true)
            {
                Thread.Sleep(8000);
                lock (mState.AccessLock)
                {
                    int lowlimit = rnd.Next(1, 100);
                    int uplimit = rnd.Next(lowlimit + 1, lowlimit + 100);
                    mState.lowerlimit = lowlimit;
                    mState.upperlimit = uplimit;

                    mLog.Info($"Updated limits: Lower = {mState.lowerlimit}, Upper = {mState.upperlimit}, Current level = {mState.currentlever}");
                }
            }
        }
    }
}

